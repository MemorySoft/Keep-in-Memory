window.themes = [
	{"name": "Default", "css":"default"},
	{"name": "Default Claro", "css":"default-clear"}
];